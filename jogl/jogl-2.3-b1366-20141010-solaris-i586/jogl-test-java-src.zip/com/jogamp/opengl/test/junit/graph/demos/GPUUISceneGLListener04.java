package com.jogamp.opengl.test.junit.graph.demos;

public class GPUUISceneGLListener04 extends GPUUISceneGLListener0A {
    public GPUUISceneGLListener04() {
        super(GPUUISceneGLListener0A.DefaultNoAADPIThreshold /* noAADPIThreshold */);
    }
}
